# Bireysel Cüz Takip · Grup okuma, kıble pusulası ve yeni ana ekran

Bu pakette iki şey var: `uygulama/` klasörü GitHub'daki `bireysel-cuz-takip` deposuna gidecek dosyalar, `sunucu/Kod.gs` de grup bilgilerini tutacak Google Apps Script kodu. Pusula ve yeni ana ekran sunucusuz çalışır. Sunucu sadece grup okuma için lazım.

## 1. Grup sunucusunu kurun (bir kerelik, 10 dakika)

1. Bilgisayardan **script.google.com** adresine girin. Uygulamayı yayınladığınız Google hesabıyla girdiğinizden emin olun.
2. Sol üstte **Yeni proje**'ye basın. Proje adını "Bireysel Cüz Takip Sunucu" yapın.
3. Açılan `Kod.gs` içindeki her şeyi silin. Paketteki `sunucu/Kod.gs` dosyasının içeriğini olduğu gibi yapıştırın, **Kaydet**'e (disket simgesi) basın.
4. Üstteki işlev listesinden **kurulum**'u seçip **Çalıştır**'a basın. Google izin isteyecek: hesabınızı seçin, "Gelişmiş" → "... (güvenli değil) sayfasına git" → **İzin ver**. Bu uyarı kendi yazdığınız kod için her zaman çıkar.
5. Çalışınca Drive'ınızda "Bireysel Cüz Takip · Gruplar" adlı bir tablo oluşur. Grupların bilgileri burada durur, silmeyin.
6. Sağ üstte **Dağıt → Yeni dağıtım**. Tür olarak **Web uygulaması** seçin.
   - Yürütme: **Ben**
   - Erişimi olanlar: **Herkes**
7. **Dağıt**'a basın, çıkan **/exec** ile biten adresi kopyalayıp bana gönderin. `ayar.js` dosyasını o adresle ben dolduracağım.

## 2. Dosyaları GitHub'a yükleyin

`bireysel-cuz-takip` deposunda **Add file → Upload files** deyip `uygulama/` klasöründeki şu dosyaları sürükleyin (eskilerin üzerine yazılır):

`index.html`, `stil.css`, `uygulama.js`, `ekler.js`, `sw.js`, `grup.js`, `kible.js`, `ayar.js`, `gizlilik.html`

Diğer dosyalar değişmedi, ama hepsini yüklemenin de zararı yok. Alttaki **Commit changes**'e basın. Bir iki dakika içinde site güncellenir; Play Store'daki uygulama da kendini yeniler, yeni .aab yüklemeye gerek yok. Telefonda değişikliği hemen görmek için uygulamayı tamamen kapatıp iki kez açın.

## 3. Play Console'da veri güvenliği formunu güncelleyin

Gruplar ad bilgisi tuttuğu için formu bir kez düzeltmek gerekiyor:

- **Uygulama içeriği → Veri güvenliği → Düzenle**
- Veri toplanıyor mu: **Evet**
- **Kişisel bilgiler → Ad** işaretleyin
  - Toplanıyor, paylaşılmıyor
  - İşleme: geçici değil
  - Zorunlu mu: **İsteğe bağlı** (kullanıcı grup özelliğini kullanmazsa ad vermez)
  - Amaç: **Uygulama işlevselliği**
- Önceden işaretli olan **Yaklaşık konum** aynen kalsın.
- Kullanıcı silme isteyebiliyor mu: **Evet** (gizlilik sayfasında yazıyor)
- Kaydet ve gönderin.

## Yeni özellikler nasıl çalışıyor

**Grup okuma.** Kim isterse alt menüdeki *Grup*'tan bir grup kurar, adını yazar ve kendi cüzünü seçer. Uygulama 6 harfli bir kod verir (örnek: P28WVN). *Davet et* tuşu WhatsApp'ta hazır bir mesaj açar; mesajdaki bağlantıya basan kişi doğrudan katılma ekranına gelir, adını yazıp boştaki cüzlerden birini seçer. 30 cüzün kimde olduğu, kimin okuduğu tek ekranda görünür. Herkes sadece kendi cüzünü "okudum" diye işaretleyebilir; grubu kuran hepsini işaretleyebilir.

Bitiş tarihi geçince herkes bir sonraki cüze kendiliğinden geçer (1. cüzdeki 2.'ye, 30.'daki 1.'ye). 30 cüz tamamlanmışsa hatim sayısı bir artar. Grubu kuran kişi *Yönetici* bölümünden haftayı elle ilerletebilir, tarihi değiştirebilir, birini çıkarabilir ya da grubu silebilir.

**Kıble pusulası.** Ana ekrandaki *Kıble* kutusundan ya da Vakitler sayfasından açılır. *Pusulayı başlat*'a basınca telefonun yön sensörü devreye girer. Kâbe yönüne 4 derece yaklaşınca daire yeşile döner, telefon hafifçe titrer. Ölçüm şaşarsa telefonu havada 8 çizer gibi birkaç kez çevirmek yeterli. Metal eşyalar ve manyetik kılıflar sapmaya yol açar.

**Ana ekran.** Üstte selamlama, miladi ve hicri tarih, bir sonraki vakte kalan süre, günün altı vakti ve hava durumu var. Altında sekiz kısayol, kaldığınız yer, grup kartı, okuma planı, günün ayeti, yaklaşan dini gün ve hadis geliyor.
