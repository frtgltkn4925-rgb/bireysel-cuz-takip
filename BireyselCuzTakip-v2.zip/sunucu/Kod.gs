// BİREYSEL CÜZ TAKİP · GRUP SUNUCUSU
// Bu kodun TAMAMINI yeni bir Apps Script projesinin Kod.gs dosyasına yapıştırın.
// Sonra üstten "kurulum" işlevini bir kez çalıştırın ve Web uygulaması olarak dağıtın.

var EN_FAZLA_GRUP_KATILIM = 30;
var HARFLER = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

function doGet() {
  return ContentService.createTextOutput("Bireysel Cüz Takip grup sunucusu çalışıyor.");
}

function doPost(e) {
  var cevap;
  try {
    var istek = JSON.parse((e && e.postData && e.postData.contents) || "{}");
    var izinli = { grupKur: grupKur, katil: katil, durum: durum, isaretle: isaretle, ayril: ayril, yonet: yonet };
    var fn = izinli[istek.fn];
    if (!fn) throw new Error("Bilinmeyen işlem");
    cevap = { ok: true, veri: fn(istek.args || {}) };
  } catch (err) {
    cevap = { ok: false, hata: String((err && err.message) || err) };
  }
  return ContentService.createTextOutput(JSON.stringify(cevap)).setMimeType(ContentService.MimeType.TEXT);
}

// ---------- Kurulum ----------
function kurulum() {
  _sayfa();
  Logger.log("Hazır. Şimdi Dağıt → Yeni dağıtım → Web uygulaması → Erişim: Herkes.");
}

function _sayfa() {
  var p = PropertiesService.getScriptProperties();
  var id = p.getProperty("tablo");
  var ss = null;
  if (id) { try { ss = SpreadsheetApp.openById(id); } catch (e) { ss = null; } }
  if (!ss) {
    ss = SpreadsheetApp.create("Bireysel Cüz Takip · Gruplar");
    p.setProperty("tablo", ss.getId());
    var s0 = ss.getSheets()[0];
    s0.setName("gruplar");
    s0.getRange(1, 1, 1, 4).setValues([["kod", "veri", "guncelleme", "ad"]]);
    s0.setFrozenRows(1);
  }
  return ss.getSheetByName("gruplar");
}

function _bul(sh, kod) {
  var f = sh.getRange("A:A").createTextFinder(kod).matchEntireCell(true).findNext();
  return f ? f.getRow() : 0;
}

function _oku(kod) {
  kod = _kod(kod);
  var sh = _sayfa(), r = _bul(sh, kod);
  if (!r) throw new Error("Bu kodla bir grup bulunamadı. Kodu kontrol edin.");
  var g = JSON.parse(sh.getRange(r, 2).getValue());
  g._satir = r;
  return g;
}

function _yaz(g) {
  var sh = _sayfa();
  var r = g._satir || _bul(sh, g.kod);
  delete g._satir;
  g.log = (g.log || []).slice(-30);
  var satir = [g.kod, JSON.stringify(g), new Date(), g.ad];
  if (r) sh.getRange(r, 1, 1, 4).setValues([satir]);
  else sh.appendRow(satir);
}

function _kilit(fn) {
  var l = LockService.getScriptLock();
  l.waitLock(20000);
  try { return fn(); } finally { l.releaseLock(); }
}

// ---------- Yardımcılar ----------
function _rastgele(n) {
  var s = "";
  for (var i = 0; i < n; i++) s += HARFLER.charAt(Math.floor(Math.random() * HARFLER.length));
  return s;
}
function _kod(k) { return String(k || "").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8); }
function _temiz(s, n) { return String(s || "").replace(/[<>]/g, "").replace(/\s+/g, " ").trim().slice(0, n || 40); }
function _bugun() { return Utilities.formatDate(new Date(), "Europe/Istanbul", "yyyy-MM-dd"); }
function _tarihEkle(iso, gun) {
  var p = String(iso).split("-").map(Number);
  return new Date(Date.UTC(p[0], p[1] - 1, p[2] + gun)).toISOString().slice(0, 10);
}
function _cuzNo(k) {
  k = Math.floor(Number(k));
  if (!(k >= 1 && k <= 30)) throw new Error("Geçersiz cüz numarası");
  return k;
}
function _uyeIndeks(g, anahtar) {
  if (!anahtar) return -1;
  for (var i = 0; i < 30; i++) if (g.yer[i] && g.yer[i].a === anahtar) return i;
  return -1;
}
function _yonetici(g, yAnahtar) { return !!yAnahtar && yAnahtar === g.y; }

// Süresi geçen haftalarda herkes bir sonraki cüze geçer.
function _haftaKontrol(g) {
  var bugun = _bugun(), degisti = false, tur = 0;
  while (g.bitis < bugun && tur < 60) {
    _dondur(g, true);
    degisti = true; tur++;
  }
  return degisti;
}
function _dondur(g, otomatik) {
  var okunan = Object.keys(g.okundu || {}).length;
  var dolu = g.yer.filter(function (x) { return x; }).length;
  if (dolu && okunan >= dolu && dolu === 30) g.hatim = (g.hatim || 0) + 1;
  g.yer = [g.yer[29]].concat(g.yer.slice(0, 29));
  g.okundu = {};
  g.bitis = _tarihEkle(g.bitis, 7);
  g.hafta = (g.hafta || 1) + 1;
  g.log.push({ t: Date.now(), m: otomatik ? "Yeni hafta: herkes bir sonraki cüze geçti" : "Yönetici yeni haftayı başlattı" });
}

function _gorunum(g, uAnahtar, yAnahtar) {
  var ben = _uyeIndeks(g, uAnahtar);
  return {
    kod: g.kod, ad: g.ad, bitis: g.bitis, hatim: g.hatim || 0, hafta: g.hafta || 1,
    yer: g.yer.map(function (x, i) { return x ? { ad: x.ad, okundu: !!g.okundu[i + 1] } : null; }),
    okundu: Object.keys(g.okundu).length,
    uye: g.yer.filter(function (x) { return x; }).length,
    ben: ben >= 0 ? ben + 1 : 0,
    yonetici: _yonetici(g, yAnahtar),
    log: (g.log || []).slice(-8).reverse()
  };
}

// ---------- İşlemler ----------
function grupKur(a) {
  var ad = _temiz(a.ad, 40), kisi = _temiz(a.kisi, 30);
  if (!ad) throw new Error("Grup adı yazın");
  if (!kisi) throw new Error("Adınızı yazın");
  var cuz = a.cuz ? _cuzNo(a.cuz) : 1;
  var bitis = /^\d{4}-\d{2}-\d{2}$/.test(String(a.bitis)) ? String(a.bitis) : _tarihEkle(_bugun(), 7);
  return _kilit(function () {
    var sh = _sayfa(), kod;
    do { kod = _rastgele(6); } while (_bul(sh, kod));
    var g = { kod: kod, ad: ad, y: _rastgele(16), bitis: bitis, hatim: 0, hafta: 1, olusturma: Date.now(), yer: [], okundu: {}, log: [] };
    for (var i = 0; i < 30; i++) g.yer.push(null);
    var u = _rastgele(14);
    g.yer[cuz - 1] = { ad: kisi, a: u, t: Date.now() };
    g.log.push({ t: Date.now(), m: kisi + " grubu kurdu" });
    _yaz(g);
    return { yAnahtar: g.y, uAnahtar: u, durum: _gorunum(g, u, g.y) };
  });
}

function katil(a) {
  var kisi = _temiz(a.kisi, 30);
  if (!kisi) throw new Error("Adınızı yazın");
  return _kilit(function () {
    var g = _oku(a.kod);
    _haftaKontrol(g);
    if (_uyeIndeks(g, a.uAnahtar) >= 0) throw new Error("Bu grupta zaten bir cüzünüz var");
    var i;
    if (a.cuz) {
      i = _cuzNo(a.cuz) - 1;
      if (g.yer[i]) throw new Error(a.cuz + ". cüz dolu. Başka bir cüz seçin.");
    } else {
      i = g.yer.indexOf(null);
      if (i < 0) throw new Error("Grup dolu: 30 cüzün hepsi alınmış");
    }
    var u = _rastgele(14);
    g.yer[i] = { ad: kisi, a: u, t: Date.now() };
    g.log.push({ t: Date.now(), m: kisi + " " + (i + 1) + ". cüzü aldı" });
    _yaz(g);
    return { uAnahtar: u, durum: _gorunum(g, u, a.yAnahtar) };
  });
}

function durum(a) {
  var g = _oku(a.kod);
  if (_haftaKontrol(g)) _kilit(function () { var g2 = _oku(a.kod); if (_haftaKontrol(g2)) _yaz(g2); g = g2; });
  return _gorunum(g, a.uAnahtar, a.yAnahtar);
}

function isaretle(a) {
  var k = _cuzNo(a.cuz);
  return _kilit(function () {
    var g = _oku(a.kod);
    _haftaKontrol(g);
    var ben = _uyeIndeks(g, a.uAnahtar);
    if (ben !== k - 1 && !_yonetici(g, a.yAnahtar)) throw new Error("Sadece kendi cüzünüzü işaretleyebilirsiniz");
    if (!g.yer[k - 1]) throw new Error("Bu cüz henüz kimseye verilmedi");
    if (a.okundu === false) {
      delete g.okundu[k];
    } else if (!g.okundu[k]) {
      g.okundu[k] = Date.now();
      g.log.push({ t: Date.now(), m: g.yer[k - 1].ad + " " + k + ". cüzü okudu" });
    }
    _yaz(g);
    return _gorunum(g, a.uAnahtar, a.yAnahtar);
  });
}

function ayril(a) {
  return _kilit(function () {
    var g = _oku(a.kod);
    var i = _uyeIndeks(g, a.uAnahtar);
    if (i < 0) return true;
    g.log.push({ t: Date.now(), m: g.yer[i].ad + " gruptan ayrıldı" });
    g.yer[i] = null;
    delete g.okundu[i + 1];
    _yaz(g);
    return true;
  });
}

function yonet(a) {
  return _kilit(function () {
    var g = _oku(a.kod);
    if (!_yonetici(g, a.yAnahtar)) throw new Error("Bu işlem için yönetici olmalısınız");
    _haftaKontrol(g);
    if (a.islem === "yeniHafta") _dondur(g, false);
    else if (a.islem === "cikar") {
      var i = _cuzNo(a.cuz) - 1;
      if (g.yer[i]) g.log.push({ t: Date.now(), m: g.yer[i].ad + " gruptan çıkarıldı" });
      g.yer[i] = null; delete g.okundu[i + 1];
    } else if (a.islem === "ayar") {
      if (a.ad) g.ad = _temiz(a.ad, 40);
      if (/^\d{4}-\d{2}-\d{2}$/.test(String(a.bitis))) g.bitis = String(a.bitis);
    } else if (a.islem === "sil") {
      var sh = _sayfa(), r = _bul(sh, g.kod);
      if (r) sh.deleteRow(r);
      return { silindi: true };
    } else throw new Error("Bilinmeyen yönetici işlemi");
    _yaz(g);
    return _gorunum(g, a.uAnahtar, a.yAnahtar);
  });
}
